# Recommender Systems

## Running

Run `python3 util.py` to split the data.
Run `python3 cur.py` to create the matrix from csv.

`python3 main.py` For collaborative and collaborative with baseline.
`python3 CUR_all.py` For CUR and SVD decompositions.
